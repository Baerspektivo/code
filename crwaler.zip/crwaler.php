<?php
/*
Plugin Name: Post logger
Description: 
Version: 1.0
Author: Lupin
*/

function check_post_changes($post_id){
    $current_post = get_post($post_id);
    $previous_post = get_post($post_id, ARRAY_A);

    if(!empty($current_post) && !empty($previous_post)){
        $post_changes = array_diff_assoc($current_post -> to_array(), $previous_post);

        if(!empty($post_changes)){
            $log_message = "Changes at blog with id $post_id" . print_r($post_changes, true);
            error_log($log_message, 3, '~/Documents/backyard/log/log.log');
        }
    }
}
add_action('save_post', 'check_post_changes');